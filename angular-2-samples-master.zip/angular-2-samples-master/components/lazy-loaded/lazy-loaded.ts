import {Component} from '@angular/core';

@Component({
    selector: 'lazy-loaded',
    templateUrl: './lazy-loaded.html'
})

export class LazyLoaded {
}