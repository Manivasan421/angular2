var Column = (function () {
    function Column(name, descr) {
        this.name = name;
        this.descr = descr;
    }
    return Column;
}());
export { Column };
