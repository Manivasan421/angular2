export class Column{

    constructor(public name: string, public descr: string){
    }
}
