export class Customer{
    firstName:string;
    lastName:string;
}