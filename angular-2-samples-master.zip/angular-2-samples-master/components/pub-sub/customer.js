var Customer = (function () {
    function Customer() {
    }
    return Customer;
}());
export { Customer };
