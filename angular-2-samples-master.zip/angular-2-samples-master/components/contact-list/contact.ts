export class Contact{

    descr = this.name + ' ' + this.phone;

    constructor(public name:string, public phone:string){
    }
}
