importScripts("../node_modules/systemjs/dist/system.js", "../node_modules/zone.js/dist/zone.min.js", "../node_modules/reflect-metadata/Reflect.js", "./config.js");
System.import("./web-worker-app.js");
//# sourceMappingURL=loader.js.map