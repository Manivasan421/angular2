var KeyMap = (function () {
    function KeyMap() {
    }
    return KeyMap;
}());
export { KeyMap };
KeyMap.spaceBar = 32;
KeyMap.enter = 13;
KeyMap.a = 65;
KeyMap.z = 90;
KeyMap.backSpace = 8;
KeyMap.zero = 48;
KeyMap.nine = 57;
