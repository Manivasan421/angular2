export class KeyMap {
    static spaceBar = 32;
    static enter = 13;
    static a = 65;
    static z = 90;
    static backSpace = 8;
    static zero = 48;
    static nine = 57;
}