var Comment = (function () {
    function Comment() {
    }
    return Comment;
}());
export { Comment };
