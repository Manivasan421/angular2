export class Comment{
    text:string;
    author:string;
}