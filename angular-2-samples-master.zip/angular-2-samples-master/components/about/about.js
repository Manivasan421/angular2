import { Component } from '@angular/core';
var About = (function () {
    function About() {
    }
    return About;
}());
export { About };
About.decorators = [
    { type: Component, args: [{
                selector: 'about',
                templateUrl: './about.html'
            },] },
];
About.ctorParameters = function () { return []; };
