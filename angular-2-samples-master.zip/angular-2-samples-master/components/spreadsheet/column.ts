export class Column{
    cellValue:String;

    constructor(public columnIndex,public rowIndex){
        this.cellValue = '';
    }
}