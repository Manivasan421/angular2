import { Component } from '@angular/core';
var Algorithms = (function () {
    function Algorithms() {
    }
    return Algorithms;
}());
export { Algorithms };
Algorithms.decorators = [
    { type: Component, args: [{
                selector: 'algorithms',
                templateUrl: './algorithms.html'
            },] },
];
Algorithms.ctorParameters = function () { return []; };
