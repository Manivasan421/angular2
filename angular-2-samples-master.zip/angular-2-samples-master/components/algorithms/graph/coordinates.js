var Coordinates = (function () {
    function Coordinates(x, y, viewContainer) {
        this.x = x;
        this.y = y;
        this.viewContainer = viewContainer;
    }
    return Coordinates;
}());
export { Coordinates };
