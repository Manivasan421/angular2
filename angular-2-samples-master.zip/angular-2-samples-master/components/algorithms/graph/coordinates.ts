export class Coordinates{
  constructor(public x, public y, public viewContainer){}
}