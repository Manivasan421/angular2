import {Component} from '@angular/core';

@Component({
    selector: 'algorithms',
    templateUrl: './algorithms.html'
})

export class Algorithms {


}
