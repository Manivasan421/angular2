import {Component} from '@angular/core';

@Component({
    selector: 'ignore-bindings',
    templateUrl: './non-bindable.html'
})

export class IgnoreBindings {

}