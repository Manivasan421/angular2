import { Component } from '@angular/core';
var IgnoreBindings = (function () {
    function IgnoreBindings() {
    }
    return IgnoreBindings;
}());
export { IgnoreBindings };
IgnoreBindings.decorators = [
    { type: Component, args: [{
                selector: 'ignore-bindings',
                templateUrl: './non-bindable.html'
            },] },
];
IgnoreBindings.ctorParameters = function () { return []; };
