var QuestionBase = (function () {
    function QuestionBase() {
    }
    return QuestionBase;
}());
export { QuestionBase };
