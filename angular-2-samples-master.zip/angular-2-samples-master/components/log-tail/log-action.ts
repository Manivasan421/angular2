import {LogEntry} from './log-entry';

export class LogAction{

    constructor(public type,public data:any){

    }
}