export class LogEntry{

    constructor(public text:string, public severity:number){

    }
}